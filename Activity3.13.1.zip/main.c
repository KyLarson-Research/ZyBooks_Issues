#include <stdio.h>

int main(void) {
   int userNum1;
   int userNum2;
   int userNum3;
   int userNum4, product;
   double ave;
   /* Type your code here. */
   scanf("%d%d%d%d", &userNum1, &userNum2, &userNum3, &userNum4);
   product = userNum1 * userNum2 * userNum3 * userNum4;
   ave = (double)(userNum1 + userNum2 + userNum3 + userNum4);
   ave /= 4;
   printf("%d %d\n%.3lf %.3lf\n", product, (int)ave, (double)product, ave);
   return 0;
}
